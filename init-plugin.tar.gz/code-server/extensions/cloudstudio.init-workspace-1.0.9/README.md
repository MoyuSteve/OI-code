# Cloud Studio 内置初始化插件
